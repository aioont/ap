from django.shortcuts import render, redirect

from store.models import Product
from core.models import Contact
from core.forms import ContactForm
from store.models import *
# Create your views here.

from userprofile import views 
from store import views

from django.contrib import messages

def frontPage(request):
    products = Product.objects.filter(status=Product.ACTIVE)[0:6]
    category = Category.objects.all()

    return render(request, 'frontPage.html', {'products': products, 'category':category})

def about(request):
    return render(request, 'about.html')

# def contact(request):
#     if request.method == 'POST':
#         full_name = request.POST.get('full_name')
#         mail=request.POST.get('mail')
#         msg_subject=request.POST.get('msg_subject')
#         msg_content=request.POST.get('msg_content')
#         contact = Contact.objects.create(full_name=full_name,mail=mail,msg_subject=msg_subject,msg_content=msg_content) 
#         messages.success(request, 'Message has been send ... ')
#     #     form = MessageForm(request.POST)
#     #     if form.is_valid():
#     #         form.save()
#     #         messages.success(request, 'Message has been send ... ')
#     #         form.cleaned_data.get('mail')
#     #     else:
#     #         messages.error(request, 'Unable to send message !') 
#     # else:
#     #     form = MessageForm()  
#     return render(request, 'contact.html')

def contact(request):

    form = ContactForm()
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()

            return redirect('frontPage')
    return render(request, 'contact.html', {'form': form})

def help(request):
    return render(request, 'help.html')

def shop(request):
    products = Product.objects.all()
    return render(request, 'shop.html', {'products': products})

def detail(request):
    return render(request, 'product_detail.html')

def checkout(request):
    return render(request, 'checkout.html')


def link(request):
    return render(request, 'link.html')
    



























